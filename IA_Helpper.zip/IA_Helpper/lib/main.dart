import 'package:flutter/material.dart';

void main() {
  runApp(const IAHelpperApp());
}

class IAHelpperApp extends StatelessWidget {
  const IAHelpperApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IA Helpper',
      home: Scaffold(
        appBar: AppBar(title: const Text('IA Helpper')),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Text('IA Helpper'),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: null,
                child: Text('Escuchar pantalla'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
