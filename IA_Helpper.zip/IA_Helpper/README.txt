IA Helpper starter project

Steps:
1. Install Flutter
2. Run: flutter pub get
3. Run: flutter run
